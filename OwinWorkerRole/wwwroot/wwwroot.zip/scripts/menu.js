/// <reference path="http://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="http://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="scripts/tools.js" /> 
$(document).ready(function () {

    //Knockout.js ViewModel:
    function MenuListViewModel() {	
        var self = this;

        //Data:
        self.availableRooms = ko.observableArray([]);//RoomId, Creator
        self.availableUsers = ko.observableArray([]);//UserName, 
        self.invitations = ko.observableArray([]);//RoomId, UserName
        self.userInfo = ko.observable();
        selectedOpponent = ko.observable();
        self.newRoom = ko.observable();

    }
    var vmm = new MenuListViewModel();

    //SignalR Hub:
    var menuHub;
    $.connection.hub.url = '/signalr';
    menuHub = $.connection.menuHub;
    if(!menuHub)console.log('hub not found');

    menuHub.client.informUserInMenuPage = function (data) {
		var value2 = ko.mapping.fromJS(data);
        vmm.availableUsers().pushIfNotExist(value2, function(e) { return e.name === value2.name && e.id === value2.id;});
    };

    menuHub.client.informUserOutMenuPage = function (data) {
		var value2 = ko.mapping.fromJS(data);
        vmm.availableUsers.pop(value2);
    };

    menuHub.client.addInvitation = function (data) {
		var value2 = ko.mapping.fromJS(data);
        vmm.invitations.push(value2);
    };

    menuHub.client.removeInvitation = function (data) {
		var value2 = ko.mapping.fromJS(data);
        vmm.invitations.pop(value2);
    };


    menuHub.client.informNewRoom = function (data) {
		var value = ko.mapping.fromJS(data);
        //vmm.AvailableRooms.removeAll();
        vmm.availableRooms.push(value);
    };
        
    $.connection.hub.logging = true;
    $.connection.hub.start().
        done(function () {

            //Operations:
            visitRoom = function (room) {
                var jsonroomId = ko.toJSON(room.id);
                location.href = 'room.html?rid=' + jsonroomId.replace(/"/g,'');
            };

            sendInvite = function () {
                var jsonuser = ko.toJSON(selectedOpponent());
                menuHub.server.createNewRoom(jsonuser);
            };

            acceptInvite = function (invitation) {
                var name = ko.toJSON(invitation.user.name);
                var uid = ko.toJSON(invitation.user.id);
                var room = ko.toJSON(invitation.roomId);
                menuHub.server.userJoinRoom(name,uid,room);
                var jsonuser = ko.toJSON(invitation);
                location.href = 'room.html?rid=' + room.replace(/"/g,'');
            };

            rejectInvite = function (rejectRoom) {
                var name = ko.toJSON(invitation.user.name);
                var uid = ko.toJSON(invitation.user.id);
                var room = ko.toJSON(invitation.roomId);
                menuHub.server.rejectInvite(name,uid,room);
            };

            signout = function () {
                if (confirm('Are you sure?')) {
                    menuHub.server.disconnect();
                    location.href = '/currentUser/Logout';
                    return true;
                } else {
                    return false;
                }
            }
            tournaments = function () {
                location.href = 'tournament.html';
            }
            settings = function () {
                location.href = 'settings.html';
            }
            help = function () {
                location.href = 'help.html';
            }

            refresh = function () {
                location.reload(true);
            }
			
            function getMenudata() {
                var request = $.ajax({
                    type: "GET",
                    datatype: "json",
                    url: "/currentUser/menu",
     				cache: false,
					success: function (data) {
                        vmm = ko.mapping.fromJS(data);
                        
						statistics = function () {
							var uId = ko.toJSON(vmm.userInfo.id);
							location.href = 'statistics.html?uid=' + uId.replace(/"/g,'');
						}
						
						ko.applyBindings(vmm);
						
                    }
                });
            }
            getMenudata();
        });
    //ko.applyBindings(vmt);

          
    // SignalR Timeout handling
    // var timeout = null;
    // var interval = 10000;
    // $.connection.hub.stateChanged(function (change) {
        // if (change.newState === $.signalR.connectionState.reconnecting) {
            // timeout = setTimeout(function () {
                // console.log('Server is unreachable, trying to reconnect...');
            // }, interval);
        // }
        // else if (timeout && change.newState === $.signalR.connectionState.connected) {
            // console.log('Server reconnected, reinitialize');
            // $.connection.some-initialize();
            // clearTimeout(timeout);
            // timeout = null;
        // }
    // });
});