/// <reference path="https://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
$(document).ready(function () {
	var isInIFrame = window.location !== window.parent.location;
	//External login does not work in frame... simple solution: remove frame.
	if(isInIFrame){
		$('#google').click(function (){ parent.location.href='/currentUser/login?Provider=Google'; });
		$('#facebook').click(function (){ parent.location.href='/currentUser/login?Provider=Facebook'; });
		$('#help').click(function (){ parent.location.href='help.html'; });
	}else{
		$('#google').click(function (){ location.href='/currentUser/login?Provider=Google'; });
		$('#facebook').click(function (){ location.href='/currentUser/login?Provider=Facebook'; });
		$('#help').click(function (){ location.href='help.html'; });
	}	
});