/// <reference path="https://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="https://cdnjs.cloudflare.com/ajax/libs/rxjs/2.2.7/rx.js" /> 
/// <reference path="scripts/tools.js" /> 
$(document).ready(function () {
    var roomId = $.QueryString["rid"];

	//Scroll chat to bottom:
	$("#msgs").scrollTop($("#msgs")[0].scrollHeight);
	
    //Knockout.js ViewModel:
    function RoomViewModel() {
        var self = this;

        //Data:
        self.id = ko.observable();
        self.name = ko.observable();
        self.gameStateMessage = ko.observable();
        self.lastActionTime = ko.observable();
        self.gameStateMessage = ko.observable();
        self.lastTurn = ko.observable();
        self.chatMessages = ko.observableArray([]);
        self.gameData = ko.observableArray([]);		
        self.dogUser = ko.observable();
        self.catUser = ko.observable();
        chatMessage = ko.observable();
        gameAction = ko.observable();

    }
	
	function getImage(imgId, data) {
		var idx = $.inArray(imgId, data);
		if(idx==-1)return "empty.png";
		return (idx%2==0?"doga.png":"cata.png");
	}
    var vmr = new RoomViewModel();

	function drawBoard(data){
		viewTurn = data.length;
		$("#turnDisplay").html(viewTurn);
		for(i=1;i<10;i++){
			$("#gameImage"+i).attr('src', '/images/' + getImage(i, data));
		}
	}

    //SignalR Hub:
    var roomHub;
    $.connection.hub.qs = { "rid" : roomId };
	$.connection.hub.url = '/signalr';
    roomHub = $.connection.roomHub;
    if (!roomHub) console.log('hub not found');

    roomHub.client.someoneSentMessage = function (message) {
        vmr.chatMessages.push(message);
		$("#msgs").scrollTop($("#msgs")[0].scrollHeight);
    };

    roomHub.client.userDidAction = function (userdata) {
		var pos = parseInt(userdata.Item2);
		vmr.gameData.push(pos);
		var data = vmr.gameData();
		vmr.lastTurn = data.length;
		drawBoard(data);
    };
	
    roomHub.client.serverNotification = function (userdata) {
		alert("User " + userdata.Item1 + " caused " + userdata.Item2);
    };
	
    roomHub.client.userInvalidAction = function (reason) {
        alert("Sorry, your action was not allowed: \r\n" + reason);
    };

    roomHub.client.resetTimer = function (timeout) {
		setupTimer(timeout);
    };
	
    $.connection.hub.logging = true;
    $.connection.hub.start().
        done(function () {

            //Operations:
            gotoFirstTurn = function () {
                viewTurn = 0;
				drawBoard(vmr.gameData().slice(0, 0));
            };
            goBackOneTurn = function () {
                viewTurn = (viewTurn > 0 ? viewTurn - 1 : 0);
				drawBoard(vmr.gameData().slice(0, viewTurn));
            };
            goFwdOneTurn = function () {
                viewTurn = viewTurn < vmr.lastTurn ? viewTurn + 1 : vmr.lastTurn;
				drawBoard(vmr.gameData().slice(0, viewTurn));
            };
            gotoLastTurn = function () {
                viewTurn = vmr.lastTurn;
				drawBoard(vmr.gameData());
            };

            leave = function () {
                if (confirm('Are you sure?')) {
                    roomHub.server.disconnect();
                    location.href = 'menu.html';
                    return true;
                } else {
                    return false;
                }
            }

            sendMessage = function () {
                var jsonmsg = ko.toJSON(chatMessage);
                roomHub.server.sendMessage(roomId, jsonmsg);
				$('#chatmsg').val("");
            }
            $('#chatmsg').on('keydown', 
                function(e) { if (e.which == 13) { 
                   roomHub.server.sendMessage(roomId, $('#chatmsg').val()); 
                   e.preventDefault(); 
                   $('#chatmsg').val("");
                } });

            doAction1 = function () { roomHub.server.doAction(1); }
            doAction2 = function () { roomHub.server.doAction(2); }
            doAction3 = function () { roomHub.server.doAction(3); }
            doAction4 = function () { roomHub.server.doAction(4); }
            doAction5 = function () { roomHub.server.doAction(5); }
            doAction6 = function () { roomHub.server.doAction(6); }
            doAction7 = function () { roomHub.server.doAction(7); }
            doAction8 = function () { roomHub.server.doAction(8); }
            doAction9 = function () { roomHub.server.doAction(9); }

            help = function () {
                location.href = 'help.html';
            }

			refresh = function () {
                location.reload(true);
            }

            function getRoomdata() {
                var request = $.ajax({
                    type: "GET",
                    datatype: "json",
					cache: false,
                    url: "/room/" + roomId,
                    success: function (data) {
                        vmr = ko.mapping.fromJS(data);
						
						vmr.lastTurn = vmr.gameData().length;
						
						drawBoard(vmr.gameData());
                        ko.applyBindings(vmr);
                    }
                });
            }

            getRoomdata();
        });

    // SignalR Timeout handling
    // var timeout = null;
    // var interval = 10000;
    // $.connection.hub.stateChanged(function (change) {
    // if (change.newState == $.signalR.connectionState.reconnecting) {
    // timeout = setTimeout(function () {
    // console.log('Server is unreachable, trying to reconnect...');
    // }, interval);
    // }
    // else if (timeout && change.newState == $.signalR.connectionState.connected) {
    // console.log('Server reconnected, reinitialize');
    // $.connection.some-initialize();
    // clearTimeout(timeout);
    // timeout = null;
    // }
    // });
});