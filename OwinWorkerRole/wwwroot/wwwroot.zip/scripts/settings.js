/// <reference path="https://code.jquery.com/jquery-2.1.0.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.4/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.2.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
$(document).ready(function () {

    //Knockout.js ViewModel:
    function SettingsViewModel() {
        var self = this;

        //Data:
        self.theme = ko.observable();
        self.visualType = ko.observable();
        self.computerLevel = ko.observable();
    }
    var vmse = new SettingsViewModel();

    function getSettingsdata() {
        var request = $.ajax({
            type: "GET",
            datatype: "json",
			cache: false,
            url: "/currentUser/settings",
            success: function (data) {
                vmse = ko.mapping.fromJS(data);
                ko.applyBindings(vmse);
            }
        });
    }
    //Operations:
    back = function () {
        window.history.back();
    };

    getSettingsdata();
});