/// <reference path="https://code.jquery.com/jquery-2.1.0.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.4/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.2.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="https://cdnjs.cloudflare.com/ajax/libs/rxjs/2.2.7/rx.js" /> 
$(document).ready(function () {

    // Querystring parsing, http://stackoverflow.com/a/3855394/17791
    (function($) {
        $.QueryString = (function(a) {
            if (a == "") return {};
            var b = {};
            for (var i = 0; i < a.length; ++i)
            {
                var p=a[i].split('=');
                if (p.length != 2) continue;
                b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
            }
            return b;
        })(window.location.search.substr(1).split('&'))
    })(jQuery);	
	
	//Array extend: http://stackoverflow.com/a/1988361
	
	// check if an element exists in array using a comparer function
	// comparer : function(currentElement)
	Array.prototype.inArray = function(comparer) { 
		for(var i=0; i < this.length; i++) { 
			if(comparer(this[i])) return true; 
		}
		return false; 
	}; 

	// adds an element to the array if it does not already exist using a comparer 
	// function
	Array.prototype.pushIfNotExist = function(element, comparer) { 
		if (!this.inArray(comparer)) {
			this.push(element);
		}
	}; 	
});

// Javascript timer: http://stackoverflow.com/a/15350128
var roomTimer;

function Decrement(secs) {
	currentMinutes = Math.floor(secs / 60);
	currentSeconds = secs % 60;
	if(currentSeconds <= 9) currentSeconds = "0" + currentSeconds;
	secs--;
	document.getElementById("timerText").innerHTML = currentMinutes + ":" + currentSeconds;
	if(secs !== -1) {
		roomTimer = window.setTimeout(function(){Decrement(secs);},1000);
	} else {
		//alert("Timer over");
	}
}

function setupTimerSeconds(secs) {
	var currentSeconds = 0;
	var currentMinutes = 0;
	if (typeof roomTimer != 'undefined') clearTimeout(roomTimer);
	roomTimer = window.setTimeout(function(){Decrement(secs);}, 1000);
}
function setupTimer(mins) {
	var secs = mins * 60;
	setupTimerSeconds(secs);
}
