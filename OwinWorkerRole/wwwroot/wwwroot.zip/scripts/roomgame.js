/// <reference path="http://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="http://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="http://cdnjs.cloudflare.com/ajax/libs/rxjs/2.2.7/rx.js" /> 
$(document).ready(function () {
	// Some game functionality here...

});