/// <reference path="https://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="scripts/tools.js" /> 
$(document).ready(function () {

	function handleResponse() {
		//alert("Ok!");
	}

	var isInIFrame = window.location !== window.parent.location;
	function login(loginUrl) {
		if(isInIFrame){
			//External login does not work in frame... simple solution: open in new window.
			var popup = window.open(loginUrl,'Cat vs Dog','width=1010,height=760');
			popup.opener.handleResponse();
		} else {
			location.href=loginUrl;
		}
		return false;
	}

	var providerId = $.QueryString["Provider"];
	if(providerId){
		$('#knownLogin').click(function (){ login('/currentUser/login?Provider='+providerId); });

		$('#google').css({visibility: "hidden", position: "absolute"});
		$('#facebook').css({visibility: "hidden", position: "absolute"});

		$('#knownLogin').css({visibility: "visible", position: "relative"});
		
	} else {
		$('#google').click(function (){ login('/currentUser/login?Provider=Google'); });
		$('#facebook').click(function (){ login('/currentUser/login?Provider=Facebook'); });

		$('#google').css({visibility: "visible", position: "relative"});
		$('#facebook').css({visibility: "visible", position: "relative"});

		$('#knownLogin').css({visibility: "hidden", position: "absolute"});
	}

	$('#help').click(function (){ login('help.html'); });
});