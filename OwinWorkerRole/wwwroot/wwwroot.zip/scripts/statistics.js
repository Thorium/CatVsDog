/// <reference path="https://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
/// <reference path="scripts/tools.js" /> 
$(document).ready(function () {
    var userId = $.QueryString["uid"];

    //Knockout.js ViewModel:
    function StatisticsViewModel() {
        var self = this;

        //Data:
        self.user = ko.observable();
        self.created = ko.observable();
        self.lastLogin = ko.observable();
        self.level = ko.observable();
        self.score = ko.observable();
        self.usageCount = ko.observable();
        self.actionsOnThisServer = ko.observableArray([]);
        self.lastRoomId = ko.observable();
		self.isCurrentUSer = ko.observable();
        self.firstEventOnline = ko.observable();
        canFindUsers = self.isCurrentUser;

        self.serverRoomCount = ko.observable();
        self.serverUserCount = ko.observable();

	}
    var vmst = new StatisticsViewModel();

    function getStatisticsdata() {
        var request = $.ajax({
            type: "GET",
            datatype: "json",
			cache: false,
            url: "/user/" + userId + "/statistics",
            success: function (data) {
                vmst = ko.mapping.fromJS(data);
                ko.applyBindings(vmst);
            },
			error: function(xhr, status, error) {
                ko.applyBindings(vmst);
				alert("User not found!");
			}
        });
    }

    //Operations:

    findUserData = function () {		
        location.href = 'statistics.html?uid=' + $("#userNameInput").val();
    };

    findUsersRoom = function (roomId) {
        location.href = 'room.html?rid=' + roomId;
    };

    back = function () {
        window.history.back();
    };

    ko.applyBindings(vmst);

    getStatisticsdata();
});