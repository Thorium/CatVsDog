/// <reference path="https://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="https://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="https://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
$(document).ready(function () {

    //Knockout.js ViewModel:
    function HelpViewModel() {
        var self = this;
    }
    var vmh = new HelpViewModel();

    //Operations:
    vmh.back = function () {
        window.history.back();
    };

    ko.applyBindings(vmh);
});