/// <reference path="http://code.jquery.com/jquery-2.0.3.min.js" /> 
/// <reference path="http://code.jquery.com/ui/1.10.3/jquery-ui.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/signalr/jquery.signalr-2.0.0.min.js" /> 
/// <reference path="http://ajax.aspnetcdn.com/ajax/knockout/knockout-2.2.1.js" /> 
$(document).ready(function () {

    //Knockout.js ViewModel:
    function SettingsViewModel() {
        var self = this;

        //Data:
        self.theme = ko.observable();
        self.visualType = ko.observable();
        self.computerLevel = ko.observable();
    }
    var vmse = new SettingsViewModel();

    function getSettingsdata() {
        var request = $.ajax({
            type: "GET",
            datatype: "json",
			cache: false,
            url: "/currentUser/settings",
            success: function (data) {
                vmse = ko.mapping.fromJS(data);
                ko.applyBindings(vmse);
            }
        });
    }
    //Operations:
    back = function () {
        window.history.back();
    };

    getSettingsdata();
});